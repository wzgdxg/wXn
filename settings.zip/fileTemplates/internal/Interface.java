/******************************************************************
 *
 *    Powered By hhdd.com.
 *
 *    Copyright (c) 2001-2022
 *    https://kada.hhdd.com/
 *
 *    Package:     ${PACKAGE_NAME}
 *
 *    Filename:    ${NAME}
 *
 *    Description: 
 *
 *    Copyright:   Copyright (c) 2001-2022
 *
 *    Company:     hhdd.com
 *
 *    @author: 王志刚
 *
 *    @version: 1.0.0
 *
 *    Create at:   ${DATE} ${TIME}
 *
 *    Revision:
 *
 *    ${DATE} ${TIME}
 *        - first revision
 *
 *****************************************************************/
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * ${NAME}
 *
 * @author wangzg
 * @version 1.0.0
 * @create ${DATE} ${TIME}
 */
public interface ${NAME} {
}